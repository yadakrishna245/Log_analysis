=====================================
  LogSherlock Pro v4.0 - Quick Start
=====================================

STEP 1: Extract this folder anywhere.

STEP 2: Open a terminal in this folder and run:

    python serve.py

STEP 3: Open your browser to:

    http://localhost:5555

STEP 4: Enter your Name and License Key.
    - Get your key from your team admin (Krishna Yada)
    - Format: LS-MASTER-XXXX-XXXX or LS-XXXX-XXXX-XXXX-XXXX

STEP 5: Start scanning! Drop .tar.gz or .zip log files.

-------------------------------------
WHY serve.py?
  - Enables GitHub Copilot One-Click Sign In (OAuth)
  - Proxies GitHub API calls (browser CORS blocks direct calls)
  - If you don't need Copilot AI, you can use:
      python -m http.server 5555

GITHUB COPILOT SETUP:
  1. Run: python serve.py
  2. Open: http://localhost:5555
  3. Go to Settings (gear icon)
  4. Click "Sign in with GitHub Copilot"
  5. Enter the code shown on GitHub
  6. Done! All AI models available.

REQUIREMENTS:
  - Python 3.x (standard library only, no pip install)
  - Modern browser (Chrome, Edge, Firefox)

TROUBLESHOOTING:
  - 'python' not found? Try: python3 serve.py
  - Port in use? Edit PORT in serve.py
  - Blank page? Clear browser cache (Ctrl+Shift+Delete)

SUPPORT: Contact Krishna Yada for license keys
-------------------------------------
(c) 2026 Krishna Yada. All Rights Reserved.
Proprietary Software - Do not redistribute.