﻿=====================================
  LogSherlock Pro - Quick Start Guide
=====================================

Step 1: Extract this folder anywhere on your computer.

Step 2: Open a terminal (Command Prompt or PowerShell) in this folder and run:
        python -m http.server 8888

Step 3: Open http://localhost:8888 in your browser.

Step 4: Enter your Name and License Key.
        (Contact Krishna Yada for a license key)

Step 5: Start scanning log files!

-------------------------------------
NOTE: Python 3.x must be installed on your system.
      The local server is needed for license validation.
-------------------------------------
