#!/usr/bin/env python3
"""
LogSherlock Pro — Local Server
Serves the app AND proxies GitHub Copilot OAuth (avoids CORS issues).
Usage: python serve.py
Then open: http://localhost:5555
"""
import http.server
import json
import urllib.request
import urllib.parse
import os
import sys

PORT = 5555
CLIENT_ID = 'Iv1.b507a08c87ecfe98'  # VS Code Copilot client ID (public)

class LogSherlockHandler(http.server.SimpleHTTPRequestHandler):
    def do_POST(self):
        if self.path == '/api/copilot/device-code':
            self._proxy_device_code()
        elif self.path == '/api/copilot/poll-token':
            self._proxy_poll_token()
        elif self.path == '/api/copilot/exchange':
            self._proxy_exchange()
        elif self.path == '/api/copilot/chat':
            self._proxy_chat()
        else:
            self.send_error(404)

    def _proxy_device_code(self):
        """Request device code from GitHub"""
        try:
            data = json.dumps({'client_id': CLIENT_ID, 'scope': 'read:user'}).encode()
            req = urllib.request.Request(
                'https://github.com/login/device/code',
                data=data,
                headers={'Content-Type': 'application/json', 'Accept': 'application/json'}
            )
            resp = urllib.request.urlopen(req, timeout=10)
            result = resp.read()
            self._send_json(200, json.loads(result))
        except Exception as e:
            self._send_json(500, {'error': str(e)})

    def _proxy_poll_token(self):
        """Poll for OAuth token"""
        try:
            length = int(self.headers.get('Content-Length', 0))
            body = json.loads(self.rfile.read(length)) if length else {}
            device_code = body.get('device_code', '')

            data = json.dumps({
                'client_id': CLIENT_ID,
                'device_code': device_code,
                'grant_type': 'urn:ietf:params:oauth:grant-type:device_code'
            }).encode()
            req = urllib.request.Request(
                'https://github.com/login/oauth/access_token',
                data=data,
                headers={'Content-Type': 'application/json', 'Accept': 'application/json'}
            )
            resp = urllib.request.urlopen(req, timeout=10)
            result = json.loads(resp.read())
            self._send_json(200, result)
        except Exception as e:
            self._send_json(500, {'error': str(e)})

    def _proxy_exchange(self):
        """Exchange OAuth token for Copilot API token"""
        try:
            length = int(self.headers.get('Content-Length', 0))
            body = json.loads(self.rfile.read(length)) if length else {}
            oauth_token = body.get('oauth_token', '')

            req = urllib.request.Request(
                'https://api.github.com/copilot_internal/v2/token',
                headers={
                    'Authorization': f'token {oauth_token}',
                    'Accept': 'application/json',
                    'User-Agent': 'LogSherlock-Pro/1.0'
                }
            )
            resp = urllib.request.urlopen(req, timeout=10)
            result = json.loads(resp.read())
            self._send_json(200, result)
        except urllib.error.HTTPError as e:
            error_body = e.read().decode() if e.fp else ''
            self._send_json(e.code, {'error': f'GitHub API error: {e.code}', 'details': error_body})
        except Exception as e:
            self._send_json(500, {'error': str(e)})

    def _proxy_chat(self):
        """Proxy chat completions to GitHub Copilot API (streaming)"""
        try:
            length = int(self.headers.get('Content-Length', 0))
            body = self.rfile.read(length) if length else b'{}'
            copilot_token = self.headers.get('X-Copilot-Token', '')

            if not copilot_token:
                self._send_json(401, {'error': 'Missing X-Copilot-Token header'})
                return

            req = urllib.request.Request(
                'https://api.githubcopilot.com/chat/completions',
                data=body,
                headers={
                    'Content-Type': 'application/json',
                    'Authorization': f'Bearer {copilot_token}',
                    'Editor-Version': 'vscode/1.92.0',
                    'Editor-Plugin-Version': 'copilot/1.200.0',
                    'Openai-Intent': 'conversation-panel',
                    'Copilot-Integration-Id': 'vscode-chat',
                    'Accept': 'text/event-stream',
                    'User-Agent': 'LogSherlock-Pro/1.0'
                }
            )
            resp = urllib.request.urlopen(req, timeout=30)

            # Stream response back to client
            self.send_response(200)
            self.send_header('Content-Type', 'text/event-stream')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.send_header('Cache-Control', 'no-cache')
            self.send_header('Transfer-Encoding', 'chunked')
            self.end_headers()

            while True:
                chunk = resp.read(4096)
                if not chunk:
                    break
                self.wfile.write(f'{len(chunk):x}\r\n'.encode())
                self.wfile.write(chunk)
                self.wfile.write(b'\r\n')
                self.wfile.flush()
            self.wfile.write(b'0\r\n\r\n')
            self.wfile.flush()
        except urllib.error.HTTPError as e:
            error_body = e.read().decode() if e.fp else ''
            self._send_json(e.code, {'error': f'Copilot API error: {e.code}', 'details': error_body[:200]})
        except Exception as e:
            self._send_json(500, {'error': str(e)})

    def _send_json(self, code, data):
        response = json.dumps(data).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', len(response))
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(response)

    def do_OPTIONS(self):
        """Handle CORS preflight"""
        self.send_response(204)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Copilot-Token')
        self.end_headers()

    def log_message(self, format, *args):
        """Cleaner logging"""
        sys.stderr.write(f"  {args[0]}\n")


if __name__ == '__main__':
    os.chdir(os.path.dirname(os.path.abspath(__file__)) if '__file__' in dir() else '.')
    print(f"""
╔══════════════════════════════════════════════════╗
║  🔍 LogSherlock Pro — Local Server              ║
╠══════════════════════════════════════════════════╣
║  Open: http://localhost:{PORT}                    ║
║  GitHub Copilot OAuth: ✅ Enabled (proxied)      ║
║  Press Ctrl+C to stop                           ║
╚══════════════════════════════════════════════════╝
""")
    server = http.server.HTTPServer(('127.0.0.1', PORT), LogSherlockHandler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n  Server stopped.")
        server.shutdown()
